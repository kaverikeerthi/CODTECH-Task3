from flask import Flask, request, render_template
import numpy as np
import pickle

app = Flask(__name__)

# Load model and scaler
model = pickle.load(open('diabetes_model.pkl', 'rb'))
scaler = pickle.load(open('scaler.pkl', 'rb'))

# List of 8 input features in order
all_features = ['Pregnancies', 'Glucose', 'BloodPressure', 'SkinThickness', 'Insulin',
                'BMI', 'DiabetesPedigreeFunction', 'Age']

# These are the 5 that were scaled
features_to_scale = ['Glucose', 'BloodPressure', 'SkinThickness', 'Insulin', 'BMI']

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    input_data = [float(request.form[feature]) for feature in all_features]
    input_dict = dict(zip(all_features, input_data))

    # Scale only selected features
    scale_input = np.array([input_dict[feature] for feature in features_to_scale]).reshape(1, -1)
    scaled_values = scaler.transform(scale_input)[0]

    # Replace original values with scaled ones
    for i, feature in enumerate(features_to_scale):
        input_dict[feature] = scaled_values[i]

    # Final input in correct order
    final_input = np.array([input_dict[feature] for feature in all_features])

    # Predict
    prediction = model.predict([final_input])[0]
    result = "Positive (Diabetic)" if prediction == 1 else "Negative (Non-Diabetic)"
    return render_template('result.html', prediction=result)

if __name__ == "__main__":
    app.run(debug=True)
